import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;

public class Pregnancy {
	private Date inseminationDate;
	
	private OC dam;
	private OC sire;
	
	private ArrayList<OC> children;
	
	private double gestationPeriod;
}
