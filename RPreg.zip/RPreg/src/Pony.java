
public class Pony {
	//Pony Tribe
	//Fuck if I know how it works
	
	//Pony Coat
	private Trait coatColour;
	private Trait coatPattern;
	private Trait coatType;
	
	//Pony Mane
	private Trait maneType;
	private Trait maneColourOne;
	private Trait maneColourTwo;
	private Trait maneColourHighlight;
	
	//Pony Tail
	private Trait tailType;
	private Trait tailColourOne;
	private Trait tailColourTwo;
	private Trait tailColourHighlight;
	
	//Pony Eyes
	private Trait eyeType;
	private Trait eyeColour;
	
	//Hoof Type
	private Trait hoofType;
	
	//Ears
	private Trait earType;
	
	//Mouth
	private Trait mouthType;	
	
	//Unicorn Horn
	private Trait hornType;
	private Trait hornSize;
	private Trait hornColour;
	
	//Pegasus Wing
	private Trait wingType;
	private Trait wingColourOne;
	private Trait wingColourTwo;
}
